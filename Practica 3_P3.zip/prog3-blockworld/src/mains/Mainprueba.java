package mains;
import model.*;
import model.entities.Player;
import model.exceptions.EntityIsDeadException;
import model.exceptions.StackSizeException;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

public class Mainprueba {
	
	public static void main(String[] args) throws StackSizeException {
		World mercury = new World(3,2,"Mercury");
		
		Location locPlayer = new Location(mercury, 0,71,0);
		Location newpos = null;
		Player player = new Player("Peter",mercury);
		
		ItemStack food = new ItemStack(Material.BEEF,5);
		ItemStack tool = new ItemStack(Material.IRON_PICKAXE,1);
		ItemStack block = new ItemStack(Material.GRANITE, 3);
		player.addItemsToInventory(food);	
		player.addItemsToInventory(tool);	
		player.addItemsToInventory(block);	
		assertEquals(20.0,player.getFoodLevel(),0.001);
		assertEquals(20.0,player.getHealth(),0.001);
		
		//usamos WOOD_SWORD 210 veces y vemos que foodLevel queda a 0 y health a 19
		try {
			player.useItemInHand(210);
		} catch (EntityIsDeadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(player.toString());
		//assertEquals(0.0,player.getFoodLevel(),0.001);
		//assertEquals(19.0,player.getHealth(),0.001);
	}
}
