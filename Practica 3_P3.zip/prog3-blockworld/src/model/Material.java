package model;

import java.util.Random;

public enum Material {
	BEDROCK(-1,'*'),
	CHEST(.1,'C'),
	SAND(0.5,'n'),
	DIRT(0.5,'d'),
	GRASS(0.6,'g'),
	STONE(1.5,'s'),
	GRANITE(1.5,'r'),
	OBSIDIAN(5,'o'),
	WATER_BUCKET(1,'W'),
	APPLE(4,'A'),
	BREAD(5,'B'),
	BEEF(8,'F'),
	IRON_SHOVEL(0.2,'>'),
	IRON_PICKAXE(0.5,'^'),
	WOOD_SWORD(1,'i'),
	IRON_SWORD(2,'I'),
	LAVA(1,'#'),
	WATER(0,'@');
	
	private double value;
	private char symbol;
	static Random rng = new Random(1L);
	
	Material(double valor, char simbolo) {
		this.value = valor;
		this.symbol = simbolo;
	}
	
	
	public boolean isBlock() {
		boolean bloque;
		if( symbol == '@' || symbol== '#' || symbol == '*' || symbol == 'C' || symbol == 'n' ||symbol == 'd'||symbol == 'g'||symbol == 's'||symbol == 'r'||symbol == 'o') {
			bloque = true;
		}
		else {
			bloque = false;
		}
		return bloque;
	}
	
	public boolean isLiquid() {
		boolean liquido;
		if(symbol == '@' || symbol== '#') {
			liquido = true;
		}
		else {
			liquido = false;
		}
		return liquido;
	}
	
	public boolean isEdible() {
		boolean edible;
		if(symbol == 'W' || symbol == 'A' || symbol == 'B' || symbol=='F') {
			edible = true;
		}
		else {
			edible = false;
		}
		return edible;
	}
	
	public boolean isWeapon() {
		boolean edible;
		if(symbol == 'i' || symbol == 'I') {
			edible = true;
		}
		else {
			edible = false;
		}
		return edible;
	}
	
	public boolean isTool() {
		boolean tool;
		if(symbol == '>' || symbol == '^') {
			tool = true;
		}
		else {
			tool = false;
		}
		return tool;
	}
	
	public double getValue() {
		return value;
	}
	
	public char getSymbol() {
		return symbol;
	}
	
	static Material getRandomItem(int first, int last) {
		int i = getRng().nextInt(last-first+1)+first;
	    return values()[i];
	}


	public static Random getRng() {
		return rng;
	}


	public static void setRng(Random rng) {
		Material.rng = rng;
	}
}
