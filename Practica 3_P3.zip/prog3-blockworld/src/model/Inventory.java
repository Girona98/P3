package model;
import java.util.ArrayList;
import java.util.List;

import model.exceptions.*;

public class Inventory {
	private ItemStack inHand;
	private ArrayList <ItemStack> items;
	
	public Inventory() {
		items = new ArrayList<ItemStack>();
		inHand = null;
	}
	
	public int addItem(ItemStack item) {
		items.add(item);
		return item.getAmount();
	}
	
	public void clear() {
		this.items.clear();
		this.inHand = null;
	}
	
	public void clear(int slot) throws BadInventoryPositionException{
		if(slot >= items.size() || slot < 0) {
			throw new BadInventoryPositionException(slot);
		}
		else {
			items.remove(slot);
		}	
	}
	
	public int first(Material mat) {
		int posi = -1;
		for(int i=0; i<items.size() && posi == -1;i++) {
			if(items.get(i).getType().getSymbol() == mat.getSymbol() ) {
				posi = i;
			}
		}
		return posi;
	}
	
	public ItemStack getItem(int slot) {
		if(slot >= 0 && slot < items.size()) {
			return items.get(slot);
		}
		else {
			return null;
		}
	}
	
	public ItemStack getItemInHand() {
		if(inHand == null) {
			return null;
		}
		else {
			return inHand;
		}
	}
	
	public int getSize() {
		return items.size();
	}
	
	public void setItem(int slot, ItemStack item) throws BadInventoryPositionException{
		boolean find = false;
		for(int i=0; i<getSize() && find == false;i++) {
			if(i==slot) {
				find = true;
			}
		}
		if(find == false) {
			throw new BadInventoryPositionException(slot);
		}
		else {
			this.items.set(slot, item);
		}
		
	}
	
	public void setItemInHand(ItemStack item) {
			this.inHand = item;
	}

	@Override
	public String toString() {
		String str;
		str = "(inHand=" + inHand + ",[";
		for(int i=0; i<this.getSize();i++) {
			str += items.get(i);
			if(i!=getSize()-1) {
				str += ", ";
			}
		}
		str += "])";
		return str;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((inHand == null) ? 0 : inHand.hashCode());
		result = prime * result + ((items == null) ? 0 : items.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Inventory other = (Inventory) obj;
		if (inHand == null) {
			if (other.inHand != null)
				return false;
		} else if (!inHand.equals(other.inHand))
			return false;
		if (items == null) {
			if (other.items != null)
				return false;
		} else if (!items.equals(other.items))
			return false;
		return true;
	}
}
