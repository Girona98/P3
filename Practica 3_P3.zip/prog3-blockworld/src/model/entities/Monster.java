package model.entities;

import model.Location;

public class Monster extends Creature {
	private static char symbol = 'M';
	
	public Monster(Location loc, double health) {
		super(loc, health);
	}

	@Override
	public char getSymbol() {
		return symbol;
	}
	
	public String toString() {
		return "Monster [location=" + location + ", health=" + this.getHealth() + "]";
	}
	
}
