package model.entities;

import model.Location;

public abstract class Creature extends LivingEntity {
	public Creature(Location loc, double health) {
		super(loc,health);
	}
	
}
