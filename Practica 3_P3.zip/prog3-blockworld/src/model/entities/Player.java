package model.entities;
import java.util.Set;

import model.Inventory;
import model.ItemStack;
import model.Location;
import model.Material;
import model.World;
import model.exceptions.*;

public class Player extends LivingEntity {
	private String name;
	private double foodLevel;
	private Inventory inventory;
	private Location orientation;
	public static final double MAX_FOODLEVEL = 20;
	private static char symbol = 'P';

	
	public Player(String name, World world) {
		super(new Location(world, 0, 0, 0), MAX_HEALTH);
		this.name = name;
		this.inventory = new Inventory();
		this.foodLevel = MAX_FOODLEVEL;
		
		try {
			this.location = new Location(world, 0, world.getHighestLocationAt(this.location).getY() + 1,0);
		} catch (BadLocationException e1) {
			throw new RuntimeException();
		}
		try {
			this.inventory.setItemInHand(new ItemStack(Material.WOOD_SWORD,1));
		} catch (StackSizeException e) {
			throw new RuntimeException();
		}
		this.orientation = new Location(world, 0, 0, 1); //orientado al sur
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public double getFoodLevel() {
		return foodLevel;
	}

	public void setFoodLevel(double food) {
		if(food <= MAX_FOODLEVEL) {
			this.foodLevel = food;
		}
		else {
			this.foodLevel = food;
		}
	}

	public int getInventorySize() {
		return this.inventory.getSize();
	}
	
	
	public Location move(int dx, int dy, int dz) throws BadLocationException, EntityIsDeadException{
		if(this.isDead() == true) {
			throw new EntityIsDeadException();
		}
		else {
			Location nueva = new Location(getLocation().getWorld(), getLocation().getX() + dx, getLocation().getY() + dy, getLocation().getZ() + dz);
			if(nueva.isFree() == false) {
				throw new BadLocationException("Bad Location");
			}
			else {
				Set<Location> vecinos = this.location.getNeighborhood();
				if(vecinos.contains(nueva) == false) {
					throw new BadLocationException("Bad Position");
				}
				else {
					this.location = nueva;
					this.decreaseFoodLevel(0.05);
					return this.location;
				}
			}
		}
	}
	
	private void decreaseFoodLevel(double d) {
		double restante = 0;
		if((this.foodLevel -d) <= 0) {
			restante = (this.foodLevel -d);
			this.foodLevel = 0;
			this.setHealth(this.getHealth() + restante);
		}
		else {
			this.foodLevel -= d;
		}
	}
	
	private void increaseFoodLevel(double d) {
		if(this.foodLevel + d >= MAX_FOODLEVEL) {
			double sumatotal = this.getFoodLevel() + d;			//sumo la comida total
			double restante = sumatotal - MAX_FOODLEVEL; 		// me quedo con el sobrante, ya que el max es 20
			this.setFoodLevel(MAX_FOODLEVEL);
			if(this.getHealth() + restante >= 20) {
				this.setHealth(MAX_HEALTH);
			}
			else {
				this.setHealth(this.getHealth() + restante);
			}
		}
		else {
			this.setFoodLevel(this.getFoodLevel() + d);
		}
	}
	
	public void addItemsToInventory(ItemStack items) {
		if(items != null) {
			this.inventory.addItem(items);
		}
	}
	
//	public void selectItem(int pos) throws BadInventoryPositionException{
//		if(pos >= 0 && pos < inventory.getSize()) {
//
//			if(inventory.getItemInHand() == null) {
//				inventory.setItemInHand(inventory.getItem(pos));
//				inventory.clear(pos);
//			}
//			else {
//				ItemStack itemaux = new ItemStack(inventory.getItemInHand());
//				inventory.setItemInHand(inventory.getItem(pos));
//				inventory.setItem(pos, itemaux);
//			}
//		}
//		else {
//			throw new BadInventoryPositionException(pos);
//		}
//	}
	
	public void selectItem(int pos) throws BadInventoryPositionException {
		if(pos >= 0 && pos < inventory.getSize()) {

			if(inventory.getItemInHand() == null) {
				inventory.setItemInHand(inventory.getItem(pos));
				inventory.clear(pos);
			}
			else {
				ItemStack itemaux = new ItemStack(inventory.getItemInHand());
				inventory.setItemInHand(inventory.getItem(pos));
				inventory.setItem(pos, itemaux);
			}
		}
		else {
			throw new BadInventoryPositionException(pos);
		}
	}
	
	public ItemStack useItemInHand(int times) throws EntityIsDeadException{
		if(isDead()==false) {
			if(times > 0) {
				if(inventory.getItemInHand() != null) {
					if(inventory.getItemInHand().getType().isEdible() == true) {
						//cuando tengo mas comida que times
						if(this.inventory.getItemInHand().getAmount() >= times) {
							for(int i = 0; i < times; i++) {
								this.increaseFoodLevel(this.inventory.getItemInHand().getType().getValue());//como times veces
							}
							int sobrante = this.inventory.getItemInHand().getAmount() - times;	//la comida que tengo menos la que me piden
							if(sobrante == 0) {
								this.inventory.setItemInHand(null);
							}
							else {
								try {
								this.inventory.getItemInHand().setAmount(sobrante);//asigno la comida que me queda
								}catch (StackSizeException e) {
									e.printStackTrace();
								}
							}
						}
						else {//cuando tengo menos comida que times
							times = this.inventory.getItemInHand().getAmount();	//asigno las veces a la comida que me queda
							for(int i = 0; i < times; i++) {
								this.increaseFoodLevel(this.inventory.getItemInHand().getType().getValue());	//como times veces
							}
							this.inventory.setItemInHand(null);	//como me he comido todo, no me queda nada	
						}						
					}
					else {
						this.decreaseFoodLevel(0.1*times);
					}		
				}
			}
			else {
				throw new IllegalArgumentException();
			}
		}
		else {
			throw new EntityIsDeadException();
		}
		return this.inventory.getItemInHand();
	}
	
	
	public Location getOrientation() {
		double dx = location.getX() + orientation.getX();
		double dy = location.getY() + orientation.getY();
		double dz = location.getZ() + orientation.getZ();
		Location orienta = new Location(this.location.getWorld(), dx, dy, dz);
		return orienta;
	}
	
	public char getSymbol() {
		return symbol;
	}
	
	public Location orientate(int x, int y, int z) throws EntityIsDeadException, BadLocationException{
		if(this.isDead() == true) {
			throw new EntityIsDeadException();
		}
		else {
			if( x == 0 && y == 0 && z == 0) {
				throw new BadLocationException("Bad Position");
			}
			else {
				if(x>=-1 && x<=1 && y>=-1 && y<=1 && z>=-1 && z<=1) {
					orientation = new Location(this.orientation.getWorld(), x, y, z);
					double dx = location.getX() + orientation.getX();
					double dy = location.getY() + orientation.getY();
					double dz = location.getZ() + orientation.getZ();
					Location orienta = new Location(this.orientation.getWorld(), dx, dy, dz);
					return orienta;
				}
				else {
					throw new BadLocationException("Bad locaiton");
				}
			}
		}
	}
	

	@Override
	public String toString() {
		String str ="";
		str = "Name=" + this.getName() + "\n";
		str += this.getLocation().toString() + "\n";
		str += "Orientation=" + orientation + "\n";
		str += "Health=" + this.getHealth() + "\n";
		str += "Food level=" + this.getFoodLevel() + "\n";
		str += "Inventory=" + this.inventory.toString() + "\n";
		return str;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		long temp;
		temp = Double.doubleToLongBits(foodLevel);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((inventory == null) ? 0 : inventory.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((orientation == null) ? 0 : orientation.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Player other = (Player) obj;
		if (Double.doubleToLongBits(foodLevel) != Double.doubleToLongBits(other.foodLevel))
			return false;
		if (inventory == null) {
			if (other.inventory != null)
				return false;
		} else if (!inventory.equals(other.inventory))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (orientation == null) {
			if (other.orientation != null)
				return false;
		} else if (!orientation.equals(other.orientation))
			return false;
		return true;
	}
}
