package model;
import model.exceptions.*;

public class ItemStack {
	private int amount;
	public static final int MAX_STACK_SIZE = 64;
	private Material type;
	
	public ItemStack(Material type, int amount) throws StackSizeException{
		if(amount <= MAX_STACK_SIZE && amount >= 1) {
			if((type.isTool() || type.isWeapon()) && amount != 1 ) {
				throw new StackSizeException();
			}
			else {
				this.amount = amount;
				this.type = type;
			}
		}
		else {
			throw new StackSizeException();
		}
	}
	
	public ItemStack(ItemStack item) {
		this.amount = item.amount;
		this.type = item.type;
	}
	
	public Material getType() {
		return type;
	}
	
	public int getAmount() {
		return amount;
	}
	
	public void setAmount(int num) throws StackSizeException{
		if(num != 1 && (this.type.isTool()  || this.getType().isWeapon())) {
			throw new StackSizeException();
		}
		else {
			if(num < 1 || num > MAX_STACK_SIZE) {
				throw new StackSizeException();
			}
			else {
				this.amount = num;
			}
		}
	}

	@Override
	public String toString() {
		return "("+this.type+","+this.amount+")";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + amount;
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ItemStack other = (ItemStack) obj;
		if (amount != other.amount)
			return false;
		if (type != other.type)
			return false;
		return true;
	}
}
