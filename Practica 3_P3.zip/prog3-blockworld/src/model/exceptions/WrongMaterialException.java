package model.exceptions;
import java.lang.Exception;
import model.Material;

public class WrongMaterialException extends Exception{
	public WrongMaterialException(Material m) {
		super("Error en material: " + m);
	}
}
