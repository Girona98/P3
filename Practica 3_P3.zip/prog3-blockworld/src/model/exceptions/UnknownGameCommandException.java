package model.exceptions;

public class UnknownGameCommandException extends Exception {
	public UnknownGameCommandException(String s) {
		super("Comando desconocido: " + s);
	}
}
