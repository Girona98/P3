package model.exceptions;
import java.lang.Exception;

public class BadInventoryPositionException extends Exception{
	public BadInventoryPositionException(int pos) {
		super("Bad position: " + pos);
	}
}
