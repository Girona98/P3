package model.exceptions;
import java.lang.Exception;

public class BadLocationException extends Exception{
	public BadLocationException(String s) {
		super(s);
	}
}
