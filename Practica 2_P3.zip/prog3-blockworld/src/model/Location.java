package model;
import java.lang.Math;
import java.util.HashSet;
import java.util.Set;
import model.exceptions.*;

public class Location {
	private double x;
	private double y;
	private double z;
	private World world;
	
	public static double UPPER_Y_VALUE = 255;
	public static double SEA_LEVEL = 63;
	
	public Location(World w, double x, double y, double z) {
		this.world = w;
		setX(x);
		setY(y);
		setZ(z);	
	}
	
	public Location(Location loc) {
		this.world = loc.world;
		this.x = loc.x;
		this.y = loc.y;
		this.z = loc.z;
	}
	
	public Location add(Location loc) {
		if(loc.world != world) {
			System.err.println("Cannot add Locations of differing worlds.");
		}
		else {
			this.x += loc.x;
			setY(this.y + loc.y);
			this.z += loc.z;
		}
		return this;
	}
	
	public double distance(Location loc) {
		if(loc.getWorld() == null || this.getWorld()==null) {
			System.err.println("Cannot measure distance to a null world");
			return -1;
		}
		else {
			if(loc.getWorld() != this.getWorld()) {
				System.err.println("Cannot measure distance between");
				return -1;
			}
		}
		double dx = this.x - loc.x;
		double dy = this.y - loc.y;
		double dz = this.z - loc.z;
		return Math.sqrt(dx*dx + dy*dy + dz*dz);
	}
	
	public World getWorld() {
		return world;
	}
	
	
	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
	/*	if(y <= UPPER_Y_VALUE) {
			if(y >= 0.0) {
				this.y = y;
			}
			else {
				this.y = 0.0;
			}
		}
		else {
			this.y = UPPER_Y_VALUE;
		}*/
		this.y = y;
	}

	public double getZ() {
		return z;
	}

	public void setZ(double z) {
		this.z = z;
	}

	public void setWorld(World world) {
		this.world = world;
	}
	
	public double length() {
		return Math.sqrt(x*x + y*y + z*z);
	}
	
	public Location multiply(double factor) {
		this.x = this.x * factor;
		setY(this.y * factor);
		this.z = this.z * factor;
		return this;
	}
	
	public Location substract(Location loc) {
		if(loc.world != this.world) {
			System.err.println("Cannot substract Locations of differing worlds");
		}
		else {
			this.x -= loc.x;
			this.setY(this.y - loc.y);
			this.z -= loc.z;
		}
		return this;
	}
	
	public Location zero() {
		x = y = z = 0;
		return this;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((world == null) ? 0 : world.hashCode());
		long temp;
		temp = Double.doubleToLongBits(x);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(y);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(z);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Location other = (Location) obj;
		if (world == null) {
			if (other.world != null)
				return false;
		} else if (!world.equals(other.world))
			return false;
		if (Double.doubleToLongBits(x) != Double.doubleToLongBits(other.x))
			return false;
		if (Double.doubleToLongBits(y) != Double.doubleToLongBits(other.y))
			return false;
		if (Double.doubleToLongBits(z) != Double.doubleToLongBits(other.z))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Location{world=" + world + ",x=" + x + ",y=" + y + ",z=" + z + "}";
	}
	
	public Location below() throws BadLocationException{
		if(this.world != null && this.y == 0) {
			throw new BadLocationException("Bad position");
		}
		else {
			return new Location(this.world,this.x, this.y - 1, this.z);
		}
	}
	
	public Location above() throws BadLocationException {
		if(this.world != null && this.y == UPPER_Y_VALUE) {
			throw new BadLocationException("Bad position");
		}
		else {
			return new Location(this.world,this.x, this.y + 1, this.z);
		}
	}
	
	public boolean isFree() {
		boolean libre = false;
		if(this.getWorld()!=null) {
			try {
				libre = this.world.isFree(this);
			} catch (BadLocationException e) {
				e.printStackTrace();
			}
		}
		return libre;
	}
	
	public Set<Location> getNeighborhood(){
		Set<Location> neigh = new HashSet<Location>();
		if(world != null) {
			for (double i = this.z - 1; i <= this.z + 1; i++) {
				for(double j = this.y + 1; j >= this.y - 1; j--) {
					for(double k = this.x - 1; k <= this.x + 1; k++) {
						if(Location.check(this.world, k, j, i)) {
							Location loc = new Location(this.world, k, j, i);
							if(!this.equals(loc)) {
								neigh.add(loc);
							}							
						}
					}
				}
			}
		}	
		else {
			for (double i = this.z - 1; i <= this.z + 1; i++) {
				for(double j = this.y + 1; j >= this.y - 1; j--) {
					for(double k = this.x - 1; k <= this.x + 1; k++) {
						Location loc = new Location(this.world, k, j, i);
						if(!this.equals(loc)) {
							neigh.add(loc);
						}
					}
				}
			}
		}
		return neigh;
	}
	
	public static boolean check(World w, double x, double y, double z) {
		boolean correcto = false;
		int tamano = w.getSize();
		int xposi = 0;
		int xnega = 0;
		int zposi = 0;
		int znega = 0;
		if(w != null) {
			if(y >= 0 && y <= UPPER_Y_VALUE) {
				if(tamano % 2 == 0) {
					xposi = tamano/2;
					xnega = 0 - tamano/2 + 1;
					zposi = tamano/2;
					znega = 0 - tamano/2 + 1;
				}
				else {
					xposi = tamano/2;
					xnega = 0 - tamano/2;
					zposi = tamano/2;
					znega = 0 - tamano/2;
				}
				if(x >= xnega && x <= xposi) {
					if(z >= znega && z <= zposi) {
						correcto = true;
					}
				}
			}
		}
		else {
			correcto = true;
		}
		
		return correcto;
	}
	
	public static boolean check(Location loc) {
		return check(loc.world, loc.getX(), loc.getY(), loc.getZ());
	}
}
