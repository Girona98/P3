package model.exceptions;
import java.lang.Exception;
public class EntityIsDeadException extends Exception{
	public EntityIsDeadException() {
		System.out.println("El player está muerto");
	}
}
