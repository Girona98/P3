package model.exceptions;
import java.lang.Exception;

public class BadInventoryPositionException extends Exception{
	public BadInventoryPositionException(int pos) {
		System.out.println("Bad position: " + pos);
	}
}
