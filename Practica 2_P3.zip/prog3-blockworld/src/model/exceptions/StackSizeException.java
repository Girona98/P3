package model.exceptions;
import java.lang.Exception;
public class StackSizeException extends Exception {
	public StackSizeException() {
		System.out.println("Error en tamaño del stack");
	}
}
