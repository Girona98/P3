package model;
import model.exceptions.*;

public class Block {
	private ItemStack drops;
	private Material type;
	
	public Block(Material type) throws WrongMaterialException{
		if(type.isBlock()) {
			this.type = type;
		}
		else {
			throw new WrongMaterialException(type);
		}
	}
	
	public Block(Block bloque) {
		this.type = bloque.getType();
		this.drops = bloque.getDrops();
	}
	
	public Material getType() {
		return this.type;
	}
	
	public ItemStack getDrops() {
		return this.drops;
	}
	
	public void setDrops(Material type, int amount) throws StackSizeException{
		if(this.getType().getSymbol() != Material.CHEST.getSymbol() && amount > 1) {
			throw new StackSizeException();
		}
		else {
			ItemStack items = new ItemStack(type, amount);
			this.drops = items;
		}
	}

	@Override
	public String toString() {
		return "[" + type + "]"; 
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Block other = (Block) obj;
		if (type != other.type)
			return false;
		return true;
	}
	
	
	
}
