package model;
import model.exceptions.*;

public class BlockWorld {

	private World world;
	private static BlockWorld instance;
	
	public static BlockWorld getInstance() {
		if(instance == null) {
			instance = new BlockWorld();
		}
		return instance;
	}
	
	private BlockWorld() {
		this.world = null;
	}
	
	public World createWorld(long seed, int size, String name) {
		this.world = new World(seed,size,name);
		return world;
	}
	
	public String showPlayerInfo(Player p) {
		String info = "";
		info = p.toString();
		try {
			info += p.getLocation().getWorld().getNeighbourhoodString(p.getLocation());
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
		return info;
	}
	
	public void movePlayer(Player p, int dx, int dy, int dz) throws BadLocationException, EntityIsDeadException{
		//Location aux = new Location(world, p.getLocation().getX() + dx, p.getLocation().getY() + dy, p.getLocation().getZ() + dz);
		p.move(dx, dy, dz);
		if(world.getItemsAt(p.getLocation()) != null) {
			p.addItemsToInventory(world.getItemsAt(p.getLocation()));
			world.removeItemsAt(p.getLocation());
		}


	}
	
	public void selectItem(Player player, int pos) throws BadInventoryPositionException{
			player.selectItem(pos);
	}
	
	public void useItem(Player p, int times) throws EntityIsDeadException {
		p.useItemInHand(times);
		
	}
}
