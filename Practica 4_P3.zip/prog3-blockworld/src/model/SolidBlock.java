package model;

import model.exceptions.*;

public class SolidBlock extends Block {

	private ItemStack drops;
	
	public SolidBlock(Material type) throws WrongMaterialException{
		super(type);
		if(type.isBlock() == false || type.isLiquid() == true ) {
			throw new WrongMaterialException(type);
		}
	}
	
	protected SolidBlock(SolidBlock solido) {
		super(solido);
		this.drops = solido.drops;
	}
	
	
	public ItemStack getDrops() {
		return this.drops;
	}
	
	public void setDrops(Material type, int amount) throws StackSizeException{
		if(this.getType().getSymbol() != Material.CHEST.getSymbol() && amount > 1) {
			throw new StackSizeException();
		}
		else {
			ItemStack items = new ItemStack(type, amount);
			this.drops = items;
		}
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((drops == null) ? 0 : drops.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		SolidBlock other = (SolidBlock) obj;
		if (drops == null) {
			if (other.drops != null)
				return false;
		} else if (!drops.equals(other.drops))
			return false;
		return true;
	}

	public boolean breaks(double damage) {
		boolean rompe = false;
		if(damage >= this.getType().getValue()) {
			rompe = true;
		}
		else {
			rompe = false;
		}
		return rompe;
	}

	@Override
	public Block clone() {
		Block copia = new SolidBlock(this);
		return copia;
	}
}
