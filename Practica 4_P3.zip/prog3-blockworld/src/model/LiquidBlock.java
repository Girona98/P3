package model;

import model.exceptions.WrongMaterialException;

public class LiquidBlock extends Block{
	
	private double damage;
	
	public LiquidBlock(Material type) throws WrongMaterialException {
		super(type);
		if(type.isLiquid() == false) {
			throw new WrongMaterialException(type);
		}
		else {
			damage = this.getType().getValue();
		}
	}
	
	protected LiquidBlock(LiquidBlock bloque) {
		super(bloque);
		this.damage = bloque.getType().getValue();
	}
	
	public double getDamage() {
		return damage;
	}
	
	public Block clone() {
		Block copia = new LiquidBlock(this);
		return copia;
	}
}
