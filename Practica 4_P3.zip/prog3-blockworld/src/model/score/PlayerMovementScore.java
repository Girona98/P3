package model.score;

import model.Location;

public class PlayerMovementScore extends Score<Location>{
	
	Location previousLocation;
	
	public PlayerMovementScore(String nombre) {
		super(nombre);
		this.previousLocation = null;
	}

	@Override
	public int compareTo(Score<Location> loc) {
		if(this.score < loc.score) {
			return -1;
		}
		else {
			if(this.score == loc.score) {
				return 0;
			}
			else {
				return 1;
			}
		}
	}

	@Override
	public void score(Location loc) {
		if(this.previousLocation != null) {
			this.score += loc.distance(this.previousLocation);
		}
		this.previousLocation = new Location(loc);
	}
	
	
}
