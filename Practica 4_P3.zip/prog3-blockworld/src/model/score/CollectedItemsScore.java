package model.score;

import model.ItemStack;
import model.Location;

public class CollectedItemsScore extends Score<ItemStack>  {

	public CollectedItemsScore(String s) {
		super(s);
	}
	
	@Override
	public int compareTo(Score<ItemStack> item) {
		if(item.score < this.score) {
			return -1;			
		}
		else {
			if(item.score == this.score) {
				return 0;
			}
			else {
				return 1;
			}
		}
	}

	@Override
	public void score(ItemStack item) {
		this.score += item.getType().getValue()*item.getAmount();
	}

}
