package model.score;
import java.util.Collections;
import java.util.SortedSet;
import java.util.TreeSet;

import model.exceptions.score.EmptyRankingException;

public class Ranking<ScoreType extends Score<?>> {
	
	private SortedSet<ScoreType> scores;
	
	public Ranking() {
		scores = new TreeSet<ScoreType>();
	}
	
	public void addScore(ScoreType tipo) {
		scores.add(tipo);
	}
	
	public SortedSet<ScoreType> getSortedRanking(){
		return scores;
	}
	
	public ScoreType getWinner() throws EmptyRankingException {
		if(scores.isEmpty()) {
			throw new EmptyRankingException();
		}
		else {
			return scores.first();
		}
	}
}
