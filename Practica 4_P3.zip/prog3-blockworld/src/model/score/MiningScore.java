package model.score;

import model.Block;

public class MiningScore extends Score<Block> {
	
	public MiningScore(String s) {
		super(s);
	}
	
	public int compareTo(Score<Block> bloque) {
		if(this.score < bloque.score) {
			return 1;
		}
		else {
			if(this.score == bloque.score) {
				return 0;
			}
			else {
				return -1;
			}
		}
	}
	
	public void score(Block bloque) {
		this.score += bloque.getType().getValue();
	}
}
