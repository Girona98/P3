package model.score;

import java.util.ArrayList;
import model.entities.*;
import model.exceptions.score.*;

// TODO: Auto-generated Javadoc
/**
 * The Class XPScore.
 */
public class XPScore extends Score<Player> {
	
	/** The scores. */
	private ArrayList<Score<?>> scores;
	
	/** The player. */
	private Player player;
	
	/**
	 * Instantiates a new XP score.
	 *
	 * @param p the p
	 */
	public XPScore(Player p) {
		super(p.getName());
		scores = new ArrayList<Score<?>>();
		player = p;
	}


	/**
	 * Compare to.
	 *
	 * @param player the player
	 * @return the int
	 */
	public int compareTo(Score<Player> player) {
		if(this.getScoring() > player.getScoring()) {
			return -1;
		}
		else {
			if(this.getScoring() == player.getScoring()) {
				return 0;
			}
			else {
				return 1;
			}
		}
	}

	/**
	 * Score.
	 *
	 * @param p the p
	 * @throws ScoreException the score exception
	 */
	public void score(Player p) throws ScoreException {
		double suma = 0;
		if(p != this.player) {
			throw new ScoreException("Puntuacion y jugador no coinciden");
		}
		else {
			double media = 0;
			for(int i = 0; i<scores.size();i++) {
				suma += scores.get(i).getScoring();
			}
			
			if(scores.size() == 0) {
				media = 0;
			}
			else {
				media = suma / scores.size();
			}
			score = media + p.getHealth() + p.getFoodLevel();
		}
	}
	
	/**
	 * Gets the scoring.
	 *
	 * @return the scoring
	 */
	public double getScoring() {
		score(player);
		return score;
	}
	
	/**
	 * Adds the score.
	 *
	 * @param puntos the puntos
	 */
	public void addScore(Score<?> puntos) {
		scores.add(puntos);
		score = this.getScoring();
	}
	

}
