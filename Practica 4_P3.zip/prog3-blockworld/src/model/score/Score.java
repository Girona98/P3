package model.score;

import model.exceptions.score.ScoreException;

public abstract class Score<T> implements Comparable<Score<T>>{
	private String playerName;
	protected double score;
	
	public Score(String nombre) {
		playerName = nombre;
		score = 0;
	}
	
	public String toString() {
		String s = playerName + ":" + score;
		return s;
	}
	
	public String getName() {
		return playerName;
	}
	
	public double getScoring() {
		return score;
	}
	
	public abstract void score(T score) throws ScoreException;
}
