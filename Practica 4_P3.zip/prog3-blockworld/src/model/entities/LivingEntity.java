package model.entities;

import model.Location;
import model.exceptions.BadLocationException;

public abstract class LivingEntity {
	protected Location location;
	private double health;
	public static final double MAX_HEALTH = 20;
	
	public LivingEntity(Location loc, double vida) {		
		this.location = loc;
		if(vida > MAX_HEALTH) {
			this.health = MAX_HEALTH;
		}
		else {
			this.health = vida;
		}
	}
	
	public double getHealth() {
		return health;
	}
	
	public void damage(double amount) {
		this.setHealth(this.health - amount);
	}

	public Location getLocation() {
		return new Location(location);
	}
	
	public void setHealth(double health) {
		if(health >= MAX_HEALTH) {
			this.health = MAX_HEALTH;
		}
		else {
			this.health = health;
		}
	}
	
	public boolean isDead() {
		boolean muerto = false;
		if(this.health <= 0) {
			muerto = true;
		}
		return muerto;
	}
	
	public abstract char getSymbol();

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(health);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((location == null) ? 0 : location.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LivingEntity other = (LivingEntity) obj;
		if (Double.doubleToLongBits(health) != Double.doubleToLongBits(other.health))
			return false;
		if (location == null) {
			if (other.location != null)
				return false;
		} else if (!location.equals(other.location))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "LivingEntity [location=" + location + ", health=" + health + "]";
	}


	
	
	
}
