package model.entities;

import model.ItemStack;
import model.Location;
import model.Material;
import model.exceptions.StackSizeException;

public class Animal extends Creature{
	private static char symbol = 'L';
	
	public Animal(Location loc, double health) {
		super(loc,health);
	}
	
	public ItemStack getDrops() {
		ItemStack carne = null;;
		try {
			carne = new ItemStack(Material.BEEF,1);
		} catch (StackSizeException e) {
			e.printStackTrace();
		}
		return carne;
	}
	
	public char getSymbol() {
		return symbol;
	}
	
	public String toString() {
		return "Animal [location=" + location + ", health=" + this.getHealth() + "]";
	}
}
