package model.exceptions;
import java.lang.Exception;
public class EntityIsDeadException extends Exception{
	public EntityIsDeadException() {
		super("El player está muerto");
	}
}
