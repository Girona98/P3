package model.exceptions.score;

public class ScoreException extends RuntimeException{
	public ScoreException(String s) {
		super(s);
	}
}
