package model.exceptions.score;

public class EmptyRankingException extends Exception{
	public EmptyRankingException() {
		super("EmptyRankingException");
	}
}
