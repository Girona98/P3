package model.exceptions;
import java.lang.Exception;
public class StackSizeException extends Exception {
	public StackSizeException() {
		super("Error en tamaño del stack");
	}
}
