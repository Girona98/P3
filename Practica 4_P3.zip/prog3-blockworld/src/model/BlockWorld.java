//package model;
//import java.io.File;
//import java.io.FileNotFoundException;
//import java.util.Scanner;
//
//import model.entities.Animal;
//import model.entities.Creature;
//import model.entities.Player;
//import model.exceptions.*;
//
//public class BlockWorld {
//
//	private World world;
//	private static BlockWorld instance;
//	
//	public static BlockWorld getInstance() {
//		if(instance == null) {
//			instance = new BlockWorld();
//		}
//		return instance;
//	}
//	
//	private BlockWorld() {
//		this.world = null;
//	}
//	
//	public World createWorld(long seed, int size, String name) {
//		this.world = new World(seed,size,name);
//		return world;
//	}
//	
//	public String showPlayerInfo(Player p) {
//		String info = "";
//		info = p.toString();
//		try {
//			info += p.getLocation().getWorld().getNeighbourhoodString(p.getLocation());
//		} catch (BadLocationException e) {
//			e.printStackTrace();
//		}
//		return info;
//	}
//	
//	public void movePlayer(Player p, int dx, int dy, int dz) throws BadLocationException, EntityIsDeadException{
//		Location aux = new Location(world, p.getLocation().getX() + dx, p.getLocation().getY() + dy, p.getLocation().getZ() + dz);
//		p.move(dx, dy, dz);
//		Block bloque = world.getBlockAt(aux);
//		
//		if(bloque != null) {
//			if(bloque.getType().isLiquid()) {
//				p.setHealth(p.getHealth() - bloque.getType().getValue());			//restamos vida al jugador
//			}
//		}
//		
//		if(world.getItemsAt(p.getLocation()) != null) {
//			p.addItemsToInventory(world.getItemsAt(p.getLocation()));
//			world.removeItemsAt(p.getLocation());
//		}
//	}
//	
//	public void selectItem(Player player, int pos) throws BadInventoryPositionException{
//			player.selectItem(pos);
//	}
//	
//	public void useItem(Player p, int times) throws EntityIsDeadException, IllegalArgumentException {
//		ItemStack mano = p.useItemInHand(times);
//		double ataque = 0.0;
//		Location objetivo = p.getOrientation();
//		ItemStack dropeo = null;
//		if(mano != null) {
//			if(mano.getType().isBlock()) {
//				ataque = times*0.1;
//			}
//			else {
//				if(mano.getType().isTool() || mano.getType().isWeapon()) {
//					ataque = mano.getType().getValue()*times;
//				}
//			}
//			if(Location.check(p.getOrientation()) && mano.getType().isEdible() == false) {
//				try {
//					if(world.getCreatureAt(objetivo) != null) {
//						Creature bicho = world.getCreatureAt(objetivo);
//						bicho.setHealth(bicho.getHealth() - ataque);
//						if(bicho.isDead()) {
//							if(bicho.getSymbol() == 'L') {
//								Animal vaca = (Animal)bicho;
//								dropeo = vaca.getDrops();
//								world.killCreature(objetivo);
//								world.addItems(objetivo, dropeo);
//							}
//							else {
//								world.killCreature(objetivo);
//							}
//						}
//						else {
//							if(bicho.getSymbol() == 'M') {
//								p.damage(0.5*times);
//							}
//						}
//					}
//					else {
//						if(world.getBlockAt(p.getOrientation()) != null) {
//							Block bloque = world.getBlockAt(objetivo);
//							if(bloque.getType().isBlock() && bloque.getType().isLiquid() == false) {
//								SolidBlock solido = (SolidBlock)bloque;
//								if(solido.breaks(ataque)) {
//									dropeo = solido.getDrops();
//									world.destroyBlockAt(objetivo);
//									if(dropeo != null) {
//										world.addItems(objetivo, dropeo);
//									}
//								}						
//							}
//						}
//						else {
//							if(mano.getType().isBlock() && mano.getType().isLiquid() == false) {
//								SolidBlock nuevo = new SolidBlock(mano.getType());
//								world.addBlock(objetivo, nuevo);
//							}
//						}
//					}
//				}
//				catch(BadLocationException | IllegalArgumentException | WrongMaterialException e) {
//					throw new RuntimeException(e.getMessage());
//				}
//			}
//		}	
//	}
//	
//	public void orientatePlayer(Player p, int dx, int dy, int dz) throws EntityIsDeadException, BadLocationException {
//			p.orientate(dx, dy, dz);
//	}
//	
//
//	
//	public void playFile(String string) throws FileNotFoundException{
//		File fich = new File(string);
//		Scanner comando = new Scanner(fich);
//		play(comando);
//		comando.close();
//	}
//	
//	public void playFromConsole() {
//		Scanner comando = new Scanner(System.in);
//		play(comando);
//		comando.close();
//	}
//	
//	private void play(Scanner sc) {
//		long seed = sc.nextLong();
//		int size = sc.nextInt();
//		//String playername = sc.next();
//		String worldname = sc.nextLine().substring(1);
//		this.createWorld(seed, size, worldname);
//		String linea = "";
//		String basura = "";
//		
//		while(sc.hasNext()) {
//			if(world.getPlayer().isDead() == true) {
//				break;
//			}
//			else {
//				linea = sc.next();		//guardo el nombre del comando
//				if(linea.equals("move")) {
//					int dx = sc.nextInt();
//					int dy = sc.nextInt();
//					int dz = sc.nextInt();
//					try {
//						this.movePlayer(world.getPlayer(), dx, dy, dz);
//					} catch (BadLocationException | EntityIsDeadException e) {
//						System.err.println(e.getMessage());
//					}
//				}
//				else {
//					if(linea.equals("orientate")){
//						int dx = sc.nextInt();
//						int dy = sc.nextInt();
//						int dz = sc.nextInt();
//						try {
//							this.orientatePlayer(world.getPlayer(), dx, dy, dz);
//						} catch (EntityIsDeadException | BadLocationException e) {
//							e.printStackTrace();
//						}
//					}
//					else {
//						if(linea.equals("useItem")) {
//							int times = sc.nextInt();
//							try {
//								this.useItem(world.getPlayer(), times);
//							} catch (IllegalArgumentException | EntityIsDeadException e) {
//								System.err.println(e.getMessage());
//							}
//							//basura ="";
//						}
//						else {
//							if(linea.equals("show")) {
//								System.out.println(this.showPlayerInfo(this.world.getPlayer()));
//							}
//							else {
//								if(linea.equals("selectItem")) {
//									int posi = sc.nextInt();
//									try {
//										this.world.getPlayer().selectItem(posi);
//									} catch (BadInventoryPositionException e) {
//										System.err.println(e.getMessage());
//									}
//								}
//								else {
//									basura = sc.nextLine();
//								}
//							}
//						}
//					}
//				}
//			}
//		}
//		
//	}	
//	
//}

package model;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.io.*;

import model.entities.*;
import model.exceptions.*;
import model.score.*;


// TODO: Auto-generated Javadoc
/**
 * The Class BlockWorld.
 */
public class BlockWorld {
	
	/** The instance. */
	private static BlockWorld instance;
	
	/** The world. */
	private World world;
	
	private PlayerMovementScore movementScore;
	private MiningScore miningScore;
	private CollectedItemsScore itemsScore;

	
	/**
	 * Gets the single instance of BlockWorld.
	 *
	 * @return single instance of BlockWorld
	 */
	public static BlockWorld getInstance() {
		if(instance == null) {
			instance = new BlockWorld();
		}
			return instance;
	}
	
	/**
	 * Instantiates a new block world.
	 */
	private BlockWorld() {
		this.world = null;
		this.itemsScore = null;
		this.miningScore = null;
		this.movementScore = null;
		
	}
	
	/**
	 * Creates the world.
	 *
	 * @param seed the seed
	 * @param size the size
	 * @param name the name
	 * @param playerName the player name
	 * @return the world
	 */
	public World createWorld(long seed, int size, String name, String playerName) {
		this.world = new World(seed, size, name, playerName);
		this.itemsScore = new CollectedItemsScore(playerName);
		this.miningScore = new MiningScore(playerName);
		this.movementScore = new PlayerMovementScore(playerName);
		return world;
	}
	
	/**
	 * Show player info.
	 *
	 * @param player the player
	 * @return the string
	 */
	public String showPlayerInfo(LivingEntity player) {
		String info="";
		try {
		info = player.toString() + this.world.getNeighbourhoodString(player.getLocation());
		info += "Scores: [items: " + this.itemsScore.getScoring() + ", blocks: " + this.miningScore.getScoring() + ", movements: " + this.movementScore.getScoring() + "] \n";
	
		}catch(BadLocationException e) {
			e.printStackTrace();
		}
		return info;
		
	}
	

	/**
	 * Move player.
	 *
	 * @param p the p
	 * @param dx the dx
	 * @param dy the dy
	 * @param dz the dz
	 * @throws EntityIsDeadException the entity is dead exception
	 * @throws BadLocationException the bad location exception
	 */
	public void movePlayer(Player p, int dx, int dy, int dz) throws EntityIsDeadException, BadLocationException {
		Location blockloc = new Location(p.getLocation().getWorld(), p.getLocation().getX() + dx, p.getLocation().getY() + dy, p.getLocation().getZ() + dz);
		Block atraviesa = this.world.getBlockAt(blockloc);

		if(atraviesa != null) {
			if(atraviesa.getType().isLiquid() == true) {
				p.move(dx, dy, dz);
				p.setHealth(p.getHealth() - atraviesa.getType().getValue()); 
				this.movementScore.score(p.getLocation());
			}	
			else {
				p.move(dx, dy, dz);
				this.movementScore.score(p.getLocation());
			}
		}
		else {
			p.move(dx, dy, dz);
			this.movementScore.score(p.getLocation());
		}
		if(this.world.getItemsAt(p.getLocation()) != null) {
			p.addItemsToInventory(this.world.getItemsAt(p.getLocation()));
			this.itemsScore.score(world.getItemsAt(p.getLocation()));
			this.world.removeItemsAt(p.getLocation());
		}
	}
	
	/**
	 * Select item.
	 *
	 * @param player the player
	 * @param pos the pos
	 * @throws BadInventoryPositionException the bad inventory position exception
	 */
	public void selectItem(Player player, int pos) throws BadInventoryPositionException {
			player.selectItem(pos);
	}
	
	/**
	 * Use item.
	 *
	 * @param p the p
	 * @param times the times
	 * @throws EntityIsDeadException the entity is dead exception
	 */
	public void useItem(Player p, int times) throws EntityIsDeadException{
			ItemStack mano;
			mano = p.useItemInHand(times);
			double ataque = 0;

			if(mano!=null) {
				if(mano.getType().isBlock()) {
					ataque = times*0.1;
				}
				else {
					ataque = mano.getType().getValue()*times;
				}
			
				if(Location.check(p.getOrientation()) && mano.getType().isEdible() == false) {
					try {
						if(this.world.getCreatureAt(p.getOrientation()) != null) {				
							Creature bicho = this.world.getCreatureAt(p.getOrientation());
							if(ataque >= bicho.getHealth()) {
								if(bicho.getSymbol() == 'L') {
									Animal a = (Animal)bicho;
									this.world.killCreature(bicho.getLocation());
									ItemStack alsuelo = a.getDrops();
									this.world.addItems(p.getOrientation(), alsuelo);
								}
								else {
									this.world.killCreature(bicho.getLocation());
								}
							}
							else {
								if(bicho.getSymbol() == 'M') {
									bicho.setHealth(bicho.getHealth() - ataque);
									this.world.getPlayer().damage(0.5*times);
								}
								else {
									bicho.setHealth(bicho.getHealth() - ataque);
								}
							}
						}
						else {
							if(this.world.getBlockAt(p.getOrientation()) != null) {			
								Block bloque = this.world.getBlockAt(p.getOrientation());
								if(bloque.getType().isBlock() == true && bloque.getType().isLiquid() == false) {
									SolidBlock solido = (SolidBlock) bloque;
									if(solido.breaks(ataque) == true){
										ItemStack dropeo = solido.getDrops();
										this.world.destroyBlockAt(p.getOrientation());
										if(dropeo != null) {
											this.world.addItems(p.getOrientation(), dropeo);
										}
										this.miningScore.score(solido);
									}
								}
							}
							else {
								if(mano.getType().isBlock() && mano.getType().isLiquid() == false) {	
									SolidBlock nuevoBloque = new SolidBlock(mano.getType());
									this.world.addBlock(p.getOrientation(), nuevoBloque);
								}
							}
						}
					} catch (BadLocationException | IllegalArgumentException | WrongMaterialException e) {
						throw new RuntimeException(e.getMessage());
					}
				}	
			}
	}

	/**
	 * Orientate player.
	 *
	 * @param p the p
	 * @param dx the dx
	 * @param dy the dy
	 * @param dz the dz
	 * @throws BadLocationException the bad location exception
	 * @throws EntityIsDeadException the entity is dead exception
	 */
	public void orientatePlayer(Player p, int dx, int dy, int dz) throws BadLocationException, EntityIsDeadException{
		p.orientate(dx, dy, dz);
	}
	

	/**
	 * Play file.
	 *
	 * @param path the path
	 * @throws FileNotFoundException the file not found exception
	 */
	public void playFile(String path) throws FileNotFoundException{
		File fich = new File(path);
		Scanner comando = new Scanner(fich);
		play(comando);
		comando.close();
	}
	
	
	/**
	 * Play from console.
	 */
	public void playFromConsole() {
		Scanner comando = new Scanner(System.in);
		play(comando);
		comando.close();
	}
	
	
	/**
	 * Play.
	 *
	 * @param sc the sc
	 */
	private void play(Scanner sc) {
		Long seed = sc.nextLong();
		int size = sc.nextInt();
		String playerName = sc.next();
		String worldname = sc.nextLine().substring(1);


		this.createWorld(seed, size, worldname, playerName);
		
		String linea = "";
		String basura = "";
		
		while(sc.hasNext()) {
			if(world.getPlayer().isDead() == true) {
				break;
			}
			linea = sc.next();
			try {
				if(linea.equals("move")) {
					int dx = sc.nextInt();
					int dy = sc.nextInt();
					int dz = sc.nextInt();
					this.movePlayer(this.world.getPlayer(), dx, dy, dz);
				}
			}catch(EntityIsDeadException | BadLocationException e) {
				System.err.println(e.getMessage());
			}
			try {
				if(linea.equals("orientate")){
					int dx = sc.nextInt();
					int dy = sc.nextInt();
					int dz = sc.nextInt();
					this.orientatePlayer(this.world.getPlayer(), dx, dy, dz);
				}
			}catch(BadLocationException | EntityIsDeadException e) {
				System.err.println(e.getMessage());
			}
			try {
				if(linea.equals("useItem")) {
					int veces = sc.nextInt();
					this.useItem(this.world.getPlayer(), veces);
				}
			}catch(EntityIsDeadException | IllegalArgumentException e) {
				System.err.println(e.getMessage());
			}catch(NullPointerException e) {
				basura = "";
			}
			if(linea.equals("show")) {
				System.out.println(this.showPlayerInfo(this.world.getPlayer()));
			}
			try {
				if(linea.equals("selectItem")) {
					int posi = sc.nextInt();
					this.world.getPlayer().selectItem(posi);
				}
				else {
					basura = sc.nextLine();
				}
			}catch(Exception e) {
				System.err.println(e.getMessage());
			}
		}
	}
	
	
	public CollectedItemsScore getItemsScore() {
		return this.itemsScore;
	}
	
	public MiningScore getMiningScore() {
		return this.miningScore;
	}
	
	public PlayerMovementScore getMovementScore() {
		return this.movementScore;
	}


	
}

