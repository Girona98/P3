package model;
import model.exceptions.*;

public abstract class Block {
	private Material type;
	
	public Block(Material type) throws WrongMaterialException{
		if(type.isBlock()) {
			this.type = type;
		}
		else {
			throw new WrongMaterialException(type);
		}
	}
	
	
	protected Block(Block bloque) {
		this.type = bloque.getType();
	}
	
	public Material getType() {
		return this.type;
	}

	public abstract Block clone(); 
	
	@Override
	public String toString() {
		return "[" + type + "]"; 
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Block other = (Block) obj;
		if (type != other.type)
			return false;
		return true;
	}
	
	
	
}
