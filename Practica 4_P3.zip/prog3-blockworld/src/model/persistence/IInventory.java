package model.persistence;

import model.ItemStack;

public interface IInventory {

	public ItemStack getItem(int pos);
	public int getSize();
	public ItemStack inHandItem();
}
