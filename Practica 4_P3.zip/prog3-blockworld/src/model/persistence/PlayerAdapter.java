package model.persistence;

import model.Location;
import model.entities.Player;

public class PlayerAdapter implements IPlayer {
	
	private Player player;
	private IInventory inventory;
	
	public PlayerAdapter(Player p) {
		this.player = p;
		this.inventory = new InventoryAdapter(p.getInventory());
	}
	@Override
	public double getHealth() {
		return this.player.getHealth();
	}

	@Override
	public IInventory getInventory() {
		return this.inventory;
	}

	@Override
	public Location getLocation() {
		return this.player.getLocation();
	}

	@Override
	public String getName() {
		return this.player.getName();
	}
	
}
