package model.persistence;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

import model.Block;
import model.ItemStack;
import model.LiquidBlock;
import model.Location;
import model.Material;
import model.World;
import model.entities.Creature;
import model.entities.Player;
import model.exceptions.BadLocationException;
import model.exceptions.WrongMaterialException;

public class WorldAdapter implements IWorld{
	
	private PlayerAdapter player;
	private World world;
	
	public WorldAdapter(World w) {
		this.world = w;
		this.player = new PlayerAdapter(w.getPlayer());
	}
	
	@Override
	public NavigableMap<Location, Block> getMapBlock(Location loc) {
		NavigableMap<Location, Block> bloques = new TreeMap<Location,Block>();
		Block bloque = null;
		for (int i=0; i<16; i++) {
			for(int j=0; j<16; j++) {
				for(int k=0; k<16; k++) {
					Location blockloc = new Location(this.world, loc.getX() + i, loc.getY() + j, loc.getZ() + k);
					Location relativa = new Location(this.world, i, j, k);
					if(Location.check(blockloc) == false) {
						bloques.put(relativa, null);
					}
					else {
						try {
							bloque = this.world.getBlockAt(blockloc);
						} catch (BadLocationException e) {
							e.printStackTrace();
						}
						if(bloque != null) {
							bloques.put(relativa, bloque);
						}
						else {
							try {
								bloques.put(relativa, new LiquidBlock(Material.AIR));
							} catch (WrongMaterialException e) {
								e.printStackTrace();
							}
						}
					}
				}
			}
		}
		return bloques;
	}

	@Override
	public int getNegativeLimit() {
		int size = this.world.getSize();
		if(size % 2 == 0) {
			return (0-size)/2 +1;
		}
		else {
			return (0-size)/2;
		}
	}

	@Override
	public IPlayer getPlayer() {
		return this.player;
	}

	@Override
	public int getPositiveLimit() {
		int size = this.world.getSize();
		return size/2;
	}

	@Override
	public List<Creature> getCreatures(Location loc) {
		List<Creature> criaturas = new ArrayList<Creature>();
		Creature criatura = null;
		for(int i=0; i<16; i++) {
			for(int j=0; j<16; j++) {
				for(int k=0; k<16; k++) {
					Location locbicho = new Location(loc.getWorld(), loc.getX() + i, loc.getY() + j, loc.getZ() + k);
					try {
						criatura = this.world.getCreatureAt(locbicho);
					} catch (BadLocationException e) {
						e.printStackTrace();
					}
					if(criatura != null) {
						criaturas.add(criatura);
					}
				}
			}
		}
		return criaturas;
	}

	@Override
	public Map<Location, ItemStack> getItems(Location loc) {
		Map<Location, ItemStack> mapaitems = new HashMap<>();
		ItemStack item = null;
		for (int i = 0; i < 16; i++) {
			for (int j = 0; j < 16; j++) {
				for (int k = 0; k < 16; k++) {
					Location locitem = new Location(loc.getWorld(), loc.getX() + i, loc.getY() + j, loc.getZ() + k);
					try {
						item = this.world.getItemsAt(locitem);
					} catch (BadLocationException e) {
						e.printStackTrace();
					}
					if(item != null) {
						mapaitems.put(locitem, item);
					}
				}
			}
		}
		return mapaitems;
	}
	
}
