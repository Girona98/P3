package model.persistence;

import model.Location;

public interface IPlayer {
	public double getHealth();
	public IInventory getInventory();
	public Location getLocation();
	public String getName();
}
