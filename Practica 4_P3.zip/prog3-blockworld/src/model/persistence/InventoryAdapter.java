package model.persistence;

import model.Inventory;
import model.ItemStack;

public class InventoryAdapter implements IInventory {
	private Inventory inventory;
	
	public InventoryAdapter(Inventory inv) {
		this.inventory = inv;
	}

	@Override
	public ItemStack getItem(int pos) {
		return this.inventory.getItem(pos);
	}

	@Override
	public int getSize() {
		return this.inventory.getSize();
	}

	@Override
	public ItemStack inHandItem() {
		return this.inventory.getItemInHand();
	}
}
