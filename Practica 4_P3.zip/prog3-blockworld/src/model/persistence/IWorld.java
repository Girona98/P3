package model.persistence;

import model.Location;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import model.Block;
import model.entities.Creature;
import model.ItemStack;

public interface IWorld {
	public NavigableMap<Location,Block> getMapBlock(Location loc);
	public int getNegativeLimit();
	public IPlayer getPlayer();
	public int getPositiveLimit();
	public List<Creature> getCreatures(Location loc);
	public Map<Location, ItemStack> getItems(Location loc);
}
