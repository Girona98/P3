//package model;
//import java.lang.Math;
//import java.util.HashSet;
//import java.util.Set;
//import model.exceptions.*;
//
//public class Location implements Comparable<Location> {
//	private double x;
//	private double y;
//	private double z;
//	private World world;
//	
//	public static double UPPER_Y_VALUE = 255;
//	public static double SEA_LEVEL = 63;
//	
//	public Location(World w, double x, double y, double z) {
//		this.world = w;
//		setX(x);
//		setY(y);
//		setZ(z);	
//	}
//	
//	public Location(Location loc) {
//		this.world = loc.world;
//		this.x = loc.x;
//		this.y = loc.y;
//		this.z = loc.z;
//	}
//	
//	public Location add(Location loc) {
//		if(loc.world != world) {
//			System.err.println("Cannot add Locations of differing worlds.");
//		}
//		else {
//			this.x += loc.x;
//			setY(this.y + loc.y);
//			this.z += loc.z;
//		}
//		return this;
//	}
//	
//	public double distance(Location loc) {
//		if(loc.getWorld() == null || this.getWorld()==null) {
//			System.err.println("Cannot measure distance to a null world");
//			return -1;
//		}
//		else {
//			if(loc.getWorld() != this.getWorld()) {
//				System.err.println("Cannot measure distance between");
//				return -1;
//			}
//		}
//		double dx = this.x - loc.x;
//		double dy = this.y - loc.y;
//		double dz = this.z - loc.z;
//		return Math.sqrt(dx*dx + dy*dy + dz*dz);
//	}
//	
//	public World getWorld() {
//		return world;
//	}
//	
//	
//	public double getX() {
//		return x;
//	}
//
//	public void setX(double x) {
//		this.x = x;
//	}
//
//	public double getY() {
//		return y;
//	}
//
//	public void setY(double y) {
//	/*	if(y <= UPPER_Y_VALUE) {
//			if(y >= 0.0) {
//				this.y = y;
//			}
//			else {
//				this.y = 0.0;
//			}
//		}
//		else {
//			this.y = UPPER_Y_VALUE;
//		}*/
//		this.y = y;
//	}
//
//	public double getZ() {
//		return z;
//	}
//
//	public void setZ(double z) {
//		this.z = z;
//	}
//
//	public void setWorld(World world) {
//		this.world = world;
//	}
//	
//	public double length() {
//		return Math.sqrt(x*x + y*y + z*z);
//	}
//	
//	public Location multiply(double factor) {
//		this.x = this.x * factor;
//		setY(this.y * factor);
//		this.z = this.z * factor;
//		return this;
//	}
//	
//	public Location substract(Location loc) {
//		if(loc.world != this.world) {
//			System.err.println("Cannot substract Locations of differing worlds");
//		}
//		else {
//			this.x -= loc.x;
//			this.setY(this.y - loc.y);
//			this.z -= loc.z;
//		}
//		return this;
//	}
//	
//	public Location zero() {
//		x = y = z = 0;
//		return this;
//	}
//
//	@Override
//	public int hashCode() {
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + ((world == null) ? 0 : world.hashCode());
//		long temp;
//		temp = Double.doubleToLongBits(x);
//		result = prime * result + (int) (temp ^ (temp >>> 32));
//		temp = Double.doubleToLongBits(y);
//		result = prime * result + (int) (temp ^ (temp >>> 32));
//		temp = Double.doubleToLongBits(z);
//		result = prime * result + (int) (temp ^ (temp >>> 32));
//		return result;
//	}
//
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		Location other = (Location) obj;
//		if (world == null) {
//			if (other.world != null)
//				return false;
//		} else if (!world.equals(other.world))
//			return false;
//		if (Double.doubleToLongBits(x) != Double.doubleToLongBits(other.x))
//			return false;
//		if (Double.doubleToLongBits(y) != Double.doubleToLongBits(other.y))
//			return false;
//		if (Double.doubleToLongBits(z) != Double.doubleToLongBits(other.z))
//			return false;
//		return true;
//	}
//
//	@Override
//	public String toString() {
//		return "Location{world=" + world + ",x=" + x + ",y=" + y + ",z=" + z + "}";
//	}
//	
//	public Location below() throws BadLocationException{
//		if(this.world != null && this.y == 0) {
//			throw new BadLocationException("Bad position");
//		}
//		else {
//			return new Location(this.world,this.x, this.y - 1, this.z);
//		}
//	}
//	
//	public Location above() throws BadLocationException {
//		if(this.world != null && this.y == UPPER_Y_VALUE) {
//			throw new BadLocationException("Bad position");
//		}
//		else {
//			return new Location(this.world,this.x, this.y + 1, this.z);
//		}
//	}
//	
//	public boolean isFree() {
//		boolean libre = false;
//		if(this.getWorld()!=null) {
//			try {
//				libre = this.world.isFree(this);
//			} catch (BadLocationException e) {
//				e.printStackTrace();
//			}
//		}
//		return libre;
//	}
//	
//	public Set<Location> getNeighborhood(){
//		Set<Location> neigh = new HashSet<Location>();
//		if(world != null) {
//			for (double i = this.z - 1; i <= this.z + 1; i++) {
//				for(double j = this.y + 1; j >= this.y - 1; j--) {
//					for(double k = this.x - 1; k <= this.x + 1; k++) {
//						if(Location.check(this.world, k, j, i)) {
//							Location loc = new Location(this.world, k, j, i);
//							if(!this.equals(loc)) {
//								neigh.add(loc);
//							}							
//						}
//						else {
//							Location loc = new Location(this.world, k, j, i);
//							if(!this.equals(loc)) {
//								neigh.add(loc);
//							}
//						}
//					}
//				}
//			}
//		}	
//		return neigh;
//	}
//	
//	public static boolean check(World w , double x, double y, double z) {
//		boolean comprobado = false;
//		int xposi = 0;
//		int xnega = 0;
//		int zposi = 0; 
//		int znega = 0;
//		if(w != null) {
//			if(y < 0 || y > Location.UPPER_Y_VALUE ) {
//				comprobado = false;
//			}
//			else {
//				int worldsize = w.getSize();
//				if(worldsize % 2 == 0) { 			
//					xposi = worldsize/2;
//					xnega = (0-worldsize)/2 + 1;
//					zposi = worldsize/2;
//					znega = (0-worldsize)/2 + 1;
//					comprobado = true;
//				}
//				else {
//					xposi = worldsize/2;
//					xnega = (0-worldsize)/2;
//					zposi = worldsize/2;
//					znega = (0-worldsize)/2;
//					comprobado = true;
//				}
//				if(x < xnega || x > xposi || z < znega || z > zposi) {
//					comprobado = false;
//				}
//			}
//		}
//		else {
//			comprobado = true;
//		}
//		return comprobado;
//	}
//	
//	public static boolean check(Location loc) {
//		return check(loc.world, loc.getX(), loc.getY(), loc.getZ());
//	}
//	
//	@Override
//	public int compareTo(Location loc) {
//		if(this.getX() < loc.getX() || (this.getX() == loc.getX() && this.getY() < loc.getY()) || (this.getX() == loc.getX() && this.getY() == loc.getY() && this.getZ() < loc.getZ()) ) {
//			return -1;			
//		}
//		else {
//			if(this.getX() == loc.getX() && this.getY() == loc.getY() && this.getZ() == loc.getZ()) {
//				return 0;
//			}
//			else {
//				return 1;
//			}
//		}
//
//	}
//	
//}

package model;
import java.util.HashSet;
import java.util.Set;

import model.exceptions.*;



// TODO: Auto-generated Javadoc
/**
 * The Class Location.
 */
public class Location implements Comparable<Location>  {


	/**
	 * To string.
	 *
	 * @return the string
	 */
	public String toString() {
		String loca = "Location{world=";
		if(world==null) {
			loca += "NULL";
		}
		else {
			loca += getWorld();
		}
		loca += ",x=" + getX() + ",y=" + getY() + ",z=" + getZ() + "}";
		return loca;
	}

	/** The Constant UPPER_Y_VALUE. */
	public final static double UPPER_Y_VALUE = 255;
	
	/** The Constant SEA_LEVEL. */
	public final static double SEA_LEVEL = 63;
	
	/** The x. */
	private double x;
	
	/** The y. */
	private double y;
	
	/** The z. */
	private double z;
	
	/** The world. */
	private World world;
	

	/**
	 * Instantiates a new location.
	 *
	 * @param w the w
	 * @param x the x
	 * @param y the y
	 * @param z the z
	 */
	public Location(World w, double x, double y, double z) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.world = w;
	}
	

	/**
	 * Instantiates a new location.
	 *
	 * @param loc the loc
	 */
	public Location(Location loc) {
		this.world = loc.getWorld();
		this.x = loc.getX();
		this.y = loc.getY();
		this.z = loc.getZ();
	}
	
	

	/**
	 * Adds the.
	 *
	 * @param loc the loc
	 * @return the location
	 */
	public Location add(Location loc) {
		if(world.equals(loc.getWorld())) {
		x += loc.getX();
		setY(y + loc.getY());
		z += loc.getZ();
		}
		else {
			System.err.println("Cannot add Loacations of differing worlds");
		}
		return this;
	}
	

	/**
	 * Substract.
	 *
	 * @param loc the loc
	 * @return the location
	 */
	public Location substract(Location loc) {
		if(world.equals(loc.getWorld())) {
		x -= loc.getX();
		setY(y - loc.getY());
		z -= loc.getZ();
		}
		else {
			System.err.println("Cannot substract Loacations of differing worlds");
		}
		return this;
	}
	

	/**
	 * Multiply.
	 *
	 * @param factor the factor
	 * @return the location
	 */
	public Location multiply(double factor) {
		x *= factor;
		setY(y * factor);
		z *= factor;
		return this;
	}
	
	/**
	 * Length.
	 *
	 * @return the double
	 */
	public double length() {
		return Math.sqrt(x*x + y*y + z*z);
	}
	
	
	/**
	 * Equals.
	 *
	 * @param obj the obj
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Location other = (Location) obj;
		if (world == null) {
			if (other.world != null)
				return false;
		} else if (!world.equals(other.world))
			return false;
		if (Double.doubleToLongBits(x) != Double.doubleToLongBits(other.x))
			return false;
		if (Double.doubleToLongBits(y) != Double.doubleToLongBits(other.y))
			return false;
		if (Double.doubleToLongBits(z) != Double.doubleToLongBits(other.z))
			return false;
		return true;
	}
	

	/**
	 * Distance.
	 *
	 * @param loc the loc
	 * @return the double
	 */
	public double distance (Location loc) {
		if(world==null || loc.getWorld()==null) {
			System.err.println("Cannot measure distance to a null world");
			return -1.0;
		}
		else if(!world.equals(loc.getWorld())){
			System.err.println("Cannot measure distance between"+ world.getName() + " and " + loc.getWorld().getName());
			return -1.0;
		}
		
		double dx = x - loc.getX();
		double dy = y - loc.getY();
		double dz = z - loc.getZ();
		return Math.sqrt(dx*dx + dy*dy + dz*dz);
	}
	


	/**
	 * Zero.
	 *
	 * @return the location
	 */
	public Location zero() {
		x = y = z = 0.0;
		return this;
	}
	

	/**
	 * Gets the x.
	 *
	 * @return the x
	 */
	public double getX() {
		return x;
	}
	

	/**
	 * Sets the x.
	 *
	 * @param x the new x
	 */
	public void setX(double x) {
		this.x = x;
	}
	

	/**
	 * Gets the y.
	 *
	 * @return the y
	 */
	public double getY() {
		return y;
	}

	/**
	 * Sets the y.
	 *
	 * @param y the new y
	 */
	public void setY(double y) {
		this.y = y;
	}
	

	/**
	 * Gets the z.
	 *
	 * @return the z
	 */
	public double getZ() {
		return z;
	}
	

	/**
	 * Sets the z.
	 *
	 * @param z the new z
	 */
	public void setZ(double z) {
		this.z = z;
	}
	

	/**
	 * Gets the world.
	 *
	 * @return the world
	 */
	public World getWorld() {
		return world;
	}
	

	/**
	 * Sets the world.
	 *
	 * @param world the new world
	 */
	public void setWorld(World world) {
		this.world = world;
	}
	

	/**
	 * Hash code.
	 *
	 * @return the int
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((world == null) ? 0 : world.hashCode());
		long temp;
		temp = Double.doubleToLongBits(x);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(y);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(z);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	

	/**
	 * Below.
	 *
	 * @return the location
	 * @throws BadLocationException the bad location exception
	 */
	public Location below() throws BadLocationException{
		String error = "Bad Location below";
		Location locbelow = new Location(this.world,this.x, this.y, this.z);
		if(this.getWorld() != null && y <= 0){
			throw new BadLocationException(error);
		}
		else {
			locbelow = new Location(this.world,this.x, this.y - 1, this.z);
		}
		return locbelow;
	}
	

	/**
	 * Above.
	 *
	 * @return the location
	 * @throws BadLocationException the bad location exception
	 */
	public Location above() throws BadLocationException{
		String error = "Bad Location above";
		Location locabove = new Location(this.world, this.x, this.y, this.z);
		if( this.getWorld() != null &&  this.y >= Location.UPPER_Y_VALUE) {
			throw new BadLocationException(error);
		}
		else {
			locabove = new Location (this.world, this.x, this.y + 1, this.z);
		}
		return locabove;
	}
	
	/**
	 * Checks if is free.
	 *
	 * @return true, if is free
	 */
	public boolean isFree() {
		boolean libre = false;
		if(this.getWorld() != null) {
			try {
				libre = this.world.isFree(this);
			}
			catch(BadLocationException e) {
				e.printStackTrace();
			}
		}
		return libre;
	}
	
	

	public Set<Location> getNeighborhood(){
		Set<Location> vecinos = new HashSet<Location>();
		for (double i = this.z - 1; i <= this.z + 1; i++) {
			for(double j = this.y + 1; j >= this.y - 1; j--) {
				for(double k = this.x - 1; k <= this.x + 1; k++) {
					Location loc = new Location(this.world, k, j, i);
					if(!this.equals(loc)) {
						if(this.world != null) {
							if(Location.check(loc)) {
								vecinos.add(loc);
							}
						}
						else {
							vecinos.add(loc);
						}
					}
				}
			}
		}
		return vecinos;
	}
	

	/**
	 * Check.
	 *
	 * @param w the w
	 * @param x the x
	 * @param y the y
	 * @param z the z
	 * @return true, if successful
	 */
	public static boolean check (World w, double x, double y, double z) {
		boolean comprobado = false;
		int xposi = 0;
		int xnega = 0;
		int zposi = 0; 
		int znega = 0;
		if(w != null) {
			if(y < 0 || y > Location.UPPER_Y_VALUE ) {
				comprobado = false;
			}
			else {
				int worldsize = w.getSize();
				if(worldsize % 2 == 0) { 			
					xposi = worldsize/2;
					xnega = (0-worldsize)/2 + 1;
					zposi = worldsize/2;
					znega = (0-worldsize)/2 + 1;
					comprobado = true;
				}
				else {
					xposi = worldsize/2;
					xnega = (0-worldsize)/2;
					zposi = worldsize/2;
					znega = (0-worldsize)/2;
					comprobado = true;
				}
				if(x < xnega || x > xposi || z < znega || z > zposi) {
					comprobado = false;
				}
			}
		}
		else {
			comprobado = true;
		}
		return comprobado;
	}

	/**
	 * Check.
	 *
	 * @param loc the loc
	 * @return true, if successful
	 */
	public static boolean check (Location loc) {
		return check(loc.getWorld(), loc.getX(), loc.getY(), loc.getZ());
	}


	@Override
	public int compareTo(Location loc) {
		if(this.getX() < loc.getX() || (this.getX() == loc.getX() && this.getY() < loc.getY()) || (this.getX() == loc.getX() && this.getY() == loc.getY() && this.getZ() < loc.getZ()) ) {
			return -1;			
		}
		else {
			if(this.getX() == loc.getX() && this.getY() == loc.getY() && this.getZ() == loc.getZ()) {
				return 0;
			}
			else {
				return 1;
			}
		}

	}
	

	
	
	
}
