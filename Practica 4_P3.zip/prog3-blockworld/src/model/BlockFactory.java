package model;

import model.exceptions.WrongMaterialException;

public class BlockFactory {
	
	public static Block createBlock(Material type) throws WrongMaterialException {
		Block bloque;
		if(type.isLiquid() == true) {
			bloque = new LiquidBlock(type);
		}
		else {
			bloque = new SolidBlock(type);
		}
		return bloque;
	}
}
